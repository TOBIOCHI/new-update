"""Export helpers shared by Flask routes and offline tests."""
import csv
import io

from cloudguard.core.rules import CHECK_TO_RULE


def findings_to_csv(details):
    """Return a UTF-8 CSV string compatible with evaluation/evaluate.py."""
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow([
        "rule_id", "resource", "service", "check", "severity",
        "category", "title", "description", "recommendation"
    ])
    for finding in details.get("findings", []):
        check = finding.get("check_name") or finding.get("check") or ""
        rule_id = finding.get("rule_id") or CHECK_TO_RULE.get(check, "")
        writer.writerow([
            rule_id, finding.get("resource", ""), finding.get("service", ""),
            check, finding.get("severity", ""), finding.get("category", ""),
            finding.get("title", ""), finding.get("description", ""),
            finding.get("recommendation", "")
        ])
    return output.getvalue()
