"""
Compare a CloudGuard CSV export (or a mapped Prowler CSV) with your ground truth
and print the Chapter 4 metrics: TP, FP, FN, TN, accuracy, precision, recall,
F1-score and false positive rate.

Usage:
    python evaluation/evaluate.py evaluation/ground_truth.csv cloudguard_scan_5.csv

ground_truth.csv has one row per (resource, rule) you deliberately set up:
    resource,rule_id,expected
    cg-test-public-policy,S3-01,FAIL      <- you made this bucket public on purpose
    cg-test-private,S3-01,PASS            <- this bucket is private, the tool must NOT flag it

The findings CSV needs at least the columns rule_id and resource.
A finding counts as a match when its rule_id is the same and the ground-truth
resource name appears inside the finding's resource text (so "sg-0abc" matches
"sg-0abc (cg-open-ssh)").
"""
import csv
import sys


def load(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def matches(gt_row, finding):
    return (finding["rule_id"].strip() == gt_row["rule_id"].strip()
            and gt_row["resource"].strip() in finding["resource"])


def evaluate(ground_truth, findings):
    tp = fp = fn = tn = 0
    detail = []
    used = set()
    for row in ground_truth:
        hit = [i for i, f in enumerate(findings) if matches(row, f)]
        used.update(hit)
        expected_fail = row["expected"].strip().upper() == "FAIL"
        if expected_fail and hit:
            tp += 1; outcome = "TP"
        elif expected_fail:
            fn += 1; outcome = "FN"
        elif hit:
            fp += 1; outcome = "FP"
        else:
            tn += 1; outcome = "TN"
        detail.append((row["resource"], row["rule_id"], row["expected"], outcome))
    unlabelled = [f for i, f in enumerate(findings) if i not in used]
    return tp, fp, fn, tn, detail, unlabelled


def pct(a, b):
    return round(100 * a / b, 2) if b else 0.0


def main(gt_path, findings_path):
    tp, fp, fn, tn, detail, unlabelled = evaluate(load(gt_path), load(findings_path))
    precision, recall = pct(tp, tp + fp), pct(tp, tp + fn)
    f1 = round(2 * precision * recall / (precision + recall), 2) if precision + recall else 0.0
    print(f"{'Resource':40} {'Rule':8} {'Expected':8} Outcome")
    for r in detail:
        print(f"{r[0]:40} {r[1]:8} {r[2]:8} {r[3]}")
    print(f"\nTP={tp}  FP={fp}  FN={fn}  TN={tn}")
    print(f"Accuracy  = {pct(tp + tn, tp + tn + fp + fn)}%")
    print(f"Precision = {precision}%")
    print(f"Recall    = {recall}%")
    print(f"F1-score  = {f1}%")
    print(f"FPR       = {pct(fp, fp + tn)}%")
    if unlabelled:
        print(f"\n{len(unlabelled)} finding(s) are not in the ground truth. Check each one by hand and either add it "
              f"to ground_truth.csv or explain it in Chapter 4:")
        for f in unlabelled:
            print(f"  {f['rule_id']:8} {f['resource']}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
